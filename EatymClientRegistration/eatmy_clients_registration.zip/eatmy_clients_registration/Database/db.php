<?php 
	$connection = mysqli_connect("localhost","root","","eatym_client_registration");
	


?>