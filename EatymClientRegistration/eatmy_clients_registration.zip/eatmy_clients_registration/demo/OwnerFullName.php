<?php 
 include('../Database/db.php');
 include('header.php');
?>


<div class="col-sm-12">
    <h2 class="text-center">Owner Full Name</h2>

    <?php
        $query = "SELECT  O_NAME FROM client_details_list";
        $result = mysqli_query($connection,$query);

            if (mysqli_num_rows($result) > 0) {
            
               echo '<table class="table table-bordered text-center">
                         <thead class="table-hover">
                         <tr>
                            
                            <th>Owner Full Name</th>
                         </tr>
                        </thead>
                    <tbody>';

                    while ($row = mysqli_fetch_assoc($result)) {
                    
                        echo '<tr>';
                            
                            echo'<td>'.$row['O_NAME'].'</td>';
                    }
                    echo '</tbody>
                       </table>';  
            }

           ?>    
           
                
     
</div>


<?php 
 include('footer.php');
?>