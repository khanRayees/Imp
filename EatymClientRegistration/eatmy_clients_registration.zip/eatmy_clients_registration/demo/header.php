<!DOCTYPE html>
<html>
    <head>
        <title>Demo of Responsive vertical navigation menu</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!--awesome font include-->
        <link type="text/css" rel="stylesheet" href="../assets/css/font-awesome.min.css" />
        <!--include plugin css--> 
        <link type="text/css" rel="stylesheet" href="../src/jquery-rvnm.css" />


        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="bootstrap/css/font-awesome-5.8.1.css">
        <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="bootstrap/css/mdb.css">
        <link rel="stylesheet" type="text/css" href="bootstrap/css/style.css">


        <!--include jquery -->
        <script type="text/javascript" src="jquery.min.js"></script>
        <!--include plugin js-->
        <script type="text/javascript" src="../src/jquery-rvnm.js"></script>
        <!--js run code-->
        <script type="text/javascript">
            $(function () {
                var rvnMenu = $("#navbar").rvnm({
//                    mode: 'mobile',
//                    responsive: false,
                    searchable: true,
                    theme: 'dark-lesb'
                });
                console.log(rvnMenu);
//                rvnMenu.setMode('minimal');
                rvnMenu.setTheme('dark-ruby');
            });
        </script>
    </head>
    <body>
        
        <div class="row">
            <div class="col-sm-4">
                <nav id="navbar" class="">
            <ul>
                <li>
                    <a href="index.php">  
                        <i class="fa fa-bell-o"></i>
                        Restaurant Full Address
                    </a>
                </li>
                <li>
                    <a href="#">  
                        <i class="fa fa-bell-o"></i>
                        Restaurant On Map
                    </a>
                    

                </li>
                <li>
                    <a href="OwnerFullName.php">
                        <i class="fa fa-plus-square"></i>
                        Owner Full Name 
                    </a>
                    

                </li>
                <li class="">
                    <a href="#">  
                        <i class="fa fa-bullhorn"></i>
                        Owner Email ID
                    </a>
                </li>
                <li>
                    <a href="#">  
                        <i class="fa fa-building"></i>
                        Owner Phone Number
                    </a>
                </li>
                <li>
                    <a href="#">  
                        <i class="fa fa-expand"></i>
                        Restaurant Manager Name
                    </a>
                </li>
                <li>
                    <a href="#">  
                        <i class="fa fa-align-center"></i>
                        Restaurant Manager Email ID
                    </a>
                    

                </li>
                <li>
                    <a href="#">  
                        <i class="fa fa-amazon"></i>
                        Restaurant Manager Phone Number
                    </a>
                </li>
                <li>
                    <a href="#">  
                        <i class="fa fa-apple"></i>
                        Restaurant Establishment Year
                    </a>
                </li>
                <li>
                    <a href="#">  
                        <i class="fa fa-expand"></i>
                        GST Details
                    </a>
                </li>
                <li>
                    <a href="#">  
                        <i class="fa fa-expand"></i>
                        Services Bundle
                    </a>
                    

                </li>
                <li>
                    <a href="#">  
                        <i class="fa fa-address-book"></i>
                        Certifications
                    </a>
                </li>
                <li>
                    <a href="#">  
                        <i class="fa fa-expand"></i>
                        Total Staff
                    </a>
                </li>
                <li>
                    <a href="#">  
                        <i class="fa fa-yoast"></i>
                        Facebook URL
                    </a>
                    

                </li>
                <li>
                    <a href="#">  
                        <i class="fa fa-bank"></i>
                        Twitter URL
                    </a>
                </li>
                <li>
                    <a href="#">  
                        <i class="fa fa-bank"></i>
                        Yuutube URL
                    </a>
                </li>
                <li>
                    <a href="#">  
                        <i class="fa fa-bank"></i>
                        Google Plus URL
                    </a>
                </li>
                <li>
                    <a href="#">  
                        <i class="fa fa-bank"></i>
                        Instagram URL
                    </a>
                </li>
                <li>
                    <a href="#">  
                        <i class="fa fa-bank"></i>
                        Pinterest URL
                    </a>
                </li>
                <li>
                    <a href="#">  
                        <i class="fa fa-bank"></i>
                        Cancel Password
                    </a>
                </li>
                <li>
                    <a href="#">  
                        <i class="fa fa-bank"></i>
                        Restaurant Logo
                    </a>
                </li>
            </ul>

        </nav>

        </div>
        
            <div id="wrapper" class="col">
                
            