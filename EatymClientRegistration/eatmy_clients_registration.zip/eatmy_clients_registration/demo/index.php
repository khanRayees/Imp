
<?php 
 include('../Database/db.php');
 include('header.php');
?>


<div class="col-sm-12">
    <h2>RESTAURANT FULL ADDRESS</h2>

    <?php
        $query = "SELECT CLIENT_ID, R_ADDRESS FROM client_details_list";
        $result = mysqli_query($connection,$query);

            if (mysqli_num_rows($result) > 0) {
            
               echo '<table class="table table-bordered">
                         <thead class="table-hover">
                         <tr>
                            <th>CLIENT_ID</th>
                            <th>Restaurant Full Address</th>
                         </tr>
                        </thead>
                    <tbody>';

                    while ($row = mysqli_fetch_assoc($result)) {
                    
                        echo '<tr>';
                            echo'<td>'.$row['CLIENT_ID'].'</td>';
                            echo'<td>'.$row['R_ADDRESS'].'</td>';
                    }
                    echo '</tbody>
                       </table>';  
            }

           ?>    
           
                
     
</div>


<?php 
 include('footer.php');
?>