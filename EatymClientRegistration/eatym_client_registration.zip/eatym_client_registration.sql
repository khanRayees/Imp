-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 02, 2020 at 10:36 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eatym_client_registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `client_details_list`
--

CREATE TABLE `client_details_list` (
  `CLIENT_ID` bigint(20) NOT NULL,
  `R_NAME` varchar(100) NOT NULL,
  `GST_NUMBER` varchar(100) NOT NULL,
  `R_ADDRESS` varchar(100) NOT NULL,
  `RS_MAP` text NOT NULL,
  `O_NAME` varchar(100) NOT NULL,
  `O_EMAIL` varchar(50) NOT NULL,
  `O_PH_NUMBER` varchar(50) NOT NULL,
  `R_M_NAME` varchar(100) NOT NULL,
  `R_M_EMAIL` varchar(50) NOT NULL,
  `R_M_NUMBER` varchar(50) NOT NULL,
  `R_E_YEAR` date NOT NULL,
  `ZOMATO_URL` varchar(100) NOT NULL,
  `SWIGGY_URL` varchar(100) NOT NULL,
  `FOOD_PANDA_URL` varchar(100) NOT NULL,
  `UBER_EATS_URL` varchar(100) NOT NULL,
  `TAX_DETAILS` varchar(100) NOT NULL,
  `SERVICES_BUNDLE` varchar(100) NOT NULL,
  `CERTIFICATION` varchar(100) NOT NULL,
  `SUBSCRIPTION` varchar(100) NOT NULL,
  `TOTAL_STAFF` varchar(50) NOT NULL,
  `FACEBOOK_URL` varchar(100) NOT NULL,
  `TWITTER_URL` varchar(100) DEFAULT NULL,
  `YOUTUBE_URL` varchar(100) NOT NULL,
  `GOOGLE_PLUS_URL` varchar(100) NOT NULL,
  `INSTAGRAM_URL` varchar(100) NOT NULL,
  `PINTEREST_URL` varchar(100) NOT NULL,
  `R_THEME_COLOR` varchar(100) NOT NULL,
  `CANCEL_PASSWORD` int(20) NOT NULL,
  `R_LOGO` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client_details_list`
--

INSERT INTO `client_details_list` (`CLIENT_ID`, `R_NAME`, `GST_NUMBER`, `R_ADDRESS`, `RS_MAP`, `O_NAME`, `O_EMAIL`, `O_PH_NUMBER`, `R_M_NAME`, `R_M_EMAIL`, `R_M_NUMBER`, `R_E_YEAR`, `ZOMATO_URL`, `SWIGGY_URL`, `FOOD_PANDA_URL`, `UBER_EATS_URL`, `TAX_DETAILS`, `SERVICES_BUNDLE`, `CERTIFICATION`, `SUBSCRIPTION`, `TOTAL_STAFF`, `FACEBOOK_URL`, `TWITTER_URL`, `YOUTUBE_URL`, `GOOGLE_PLUS_URL`, `INSTAGRAM_URL`, `PINTEREST_URL`, `R_THEME_COLOR`, `CANCEL_PASSWORD`, `R_LOGO`) VALUES
(1, 'Rayees khan', '10002540', 'Begumpet', 'hyderabad', 'khan', 'krayees282@gmail.com', '9554540271', 'khan Rayees', 'krayees394@gmail.com', '7880707871', '0000-00-00', 'htttps://gomato.com', 'https://swiggy.com', 'https://foodpanda.com', 'https://uber.com', 'hyderabad', '654395', 'eatmy', 'subscriber', '3666', 'https://facebook.com', 'https://twitter.com', 'https://youtube.com', 'https://google_plus.com', 'https://instagram.com', 'https://pinterest.com', 'red', 654, 'a1.jpg'),
(2, 'Rayees khan', '10002540', 'Begumpet', 'hyderabad', 'khan', 'krayees282@gmail.com', '9554540271', 'khan Rayees', 'krayees394@gmail.com', '7880707871', '0000-00-00', 'htttps://gomato.com', 'https://swiggy.com', 'https://foodpanda.com', 'https://uber.com', 'hyderabad', '654395', 'eatmy', 'subscriber', '3666', 'https://facebook.com', 'https://twitter.com', 'https://youtube.com', 'https://google_plus.com', 'https://instagram.com', 'https://pinterest.com', 'red', 654, 'a1.jpg'),
(3, 'Sameer', '52220115', 'Paradise', 'paradise', 'zahoor', 'sameer@gmail.com', '653513561354', 'qazi', 'qazi@gmail.com', '963542308', '0000-00-00', '12344', 'https://Swiggy.com', 'https://foodpanda.com', 'https:ubereats.com', '55646546546', 'case', 'eatmy', 'subscriber', '6565', 'https:facebook.com', 'https:twitter.com', 'https://youtube.com', 'https://googleplus.com', 'https://instagram.com', 'https://pinterest.com', 'blue', 6543, 'goo.jpg'),
(4, 'Sameer', '52220115', 'Paradise', 'paradise', 'zahoor', 'sameer@gmail.com', '653513561354', 'qazi', 'qazi@gmail.com', '963542308', '0000-00-00', '12344', 'https://Swiggy.com', 'https://foodpanda.com', 'https:ubereats.com', '55646546546', 'case', 'eatmy', 'subscriber', '6565', 'https:facebook.com', 'https:twitter.com', 'https://youtube.com', 'https://googleplus.com', 'https://instagram.com', 'https://pinterest.com', 'blue', 6543, 'goo.jpg'),
(5, 'AL_Hayat', '6543', 'Begumbet', 'brgumprt', 'Khan Rayees', 'krayees282@gmail.com', '9554540271', 'hayat', 'alhat@gmail.com', '99868692', '0000-00-00', 'https:gomato.com', 'https:swiggy.com', 'https:foodpanda.com', 'https:ubereats.com', '6536325', '86954', 'Owner', '2019', '8654', 'https:facebook.com', 'https:twitter.com', 'https:youtube.com', 'https:google_plus.com', 'https:instagram.com', 'https:pintrest.com', 'yellow', 8523, 'hayat.jpg'),
(6, 'AL_Hayat', '6543', 'Begumbet', 'brgumprt', 'Khan Rayees', 'krayees282@gmail.com', '9554540271', 'hayat', 'alhat@gmail.com', '99868692', '0000-00-00', 'https:gomato.com', 'https:swiggy.com', 'https:foodpanda.com', 'https:ubereats.com', '6536325', '86954', 'Owner', '2019', '8654', 'https:facebook.com', 'https:twitter.com', 'https:youtube.com', 'https:google_plus.com', 'https:instagram.com', 'https:pintrest.com', 'yellow', 8523, 'hayat.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `client_details_list`
--
ALTER TABLE `client_details_list`
  ADD PRIMARY KEY (`CLIENT_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `client_details_list`
--
ALTER TABLE `client_details_list`
  MODIFY `CLIENT_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
